import type { Grievance } from "./types"

const GRIEVANCES_KEY = "grievances_data"

export function getGrievances(): Grievance[] {
  if (typeof window === "undefined") return []

  const data = localStorage.getItem(GRIEVANCES_KEY)
  return data ? JSON.parse(data) : []
}

export function saveGrievances(grievances: Grievance[]): void {
  if (typeof window === "undefined") return
  localStorage.setItem(GRIEVANCES_KEY, JSON.stringify(grievances))
}

export function addGrievance(grievance: Grievance): void {
  const grievances = getGrievances()
  grievances.unshift(grievance) // Add to beginning
  saveGrievances(grievances)
}

export function updateGrievance(id: string, updates: Partial<Grievance>): void {
  const grievances = getGrievances()
  const index = grievances.findIndex((g) => g.id === id)

  if (index !== -1) {
    grievances[index] = {
      ...grievances[index],
      ...updates,
      updatedAt: new Date().toISOString(),
    }
    saveGrievances(grievances)
  }
}

export function getGrievanceById(id: string): Grievance | null {
  const grievances = getGrievances()
  return grievances.find((g) => g.id === id) || null
}

export function getGrievancesByUserId(userId: string): Grievance[] {
  const grievances = getGrievances()
  return grievances.filter((g) => g.citizenId === userId)
}

export function deleteGrievance(id: string): void {
  const grievances = getGrievances()
  const filtered = grievances.filter((g) => g.id !== id)
  saveGrievances(filtered)
}
