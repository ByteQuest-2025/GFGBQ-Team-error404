import type { User } from "./types"

const AUTH_KEY = "grievance_auth"
const USERS_KEY = "grievance_users"

// Initialize with default admin and citizen users
const DEFAULT_USERS: User[] = [
  {
    id: "admin-1",
    email: "admin@gov.in",
    name: "Admin User",
    role: "admin",
    createdAt: new Date().toISOString(),
  },
  {
    id: "citizen-1",
    email: "citizen@example.com",
    name: "John Citizen",
    role: "citizen",
    createdAt: new Date().toISOString(),
  },
]

export function initializeUsers() {
  if (typeof window === "undefined") return

  const existing = localStorage.getItem(USERS_KEY)
  if (!existing) {
    localStorage.setItem(USERS_KEY, JSON.stringify(DEFAULT_USERS))
  }
}

export function login(email: string, password: string): User | null {
  if (typeof window === "undefined") return null

  initializeUsers()
  const users = JSON.parse(localStorage.getItem(USERS_KEY) || "[]") as User[]
  const user = users.find((u) => u.email === email)

  if (user) {
    localStorage.setItem(AUTH_KEY, JSON.stringify(user))
    return user
  }

  return null
}

export function register(email: string, name: string, password: string): User | null {
  if (typeof window === "undefined") return null

  initializeUsers()
  const users = JSON.parse(localStorage.getItem(USERS_KEY) || "[]") as User[]

  if (users.find((u) => u.email === email)) {
    return null // User already exists
  }

  const newUser: User = {
    id: `citizen-${Date.now()}`,
    email,
    name,
    role: "citizen",
    createdAt: new Date().toISOString(),
  }

  users.push(newUser)
  localStorage.setItem(USERS_KEY, JSON.stringify(users))
  localStorage.setItem(AUTH_KEY, JSON.stringify(newUser))

  return newUser
}

export function logout() {
  if (typeof window === "undefined") return
  localStorage.removeItem(AUTH_KEY)
}

export function getCurrentUser(): User | null {
  if (typeof window === "undefined") return null

  const userStr = localStorage.getItem(AUTH_KEY)
  if (!userStr) return null

  return JSON.parse(userStr) as User
}

export function isAuthenticated(): boolean {
  return getCurrentUser() !== null
}

export function isAdmin(): boolean {
  const user = getCurrentUser()
  return user?.role === "admin"
}
