"use client"

import { useState } from "react"
import type { Grievance, GrievanceStatus } from "@/lib/types"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { updateGrievance } from "@/lib/grievance-storage"
import { Separator } from "@/components/ui/separator"
import { format } from "date-fns"
import { Calendar, MapPin, FileText, Mic, Brain, TrendingUp, Target } from "lucide-react"

interface GrievanceDetailModalProps {
  grievance: Grievance
  onClose: () => void
}

export function GrievanceDetailModal({ grievance, onClose }: GrievanceDetailModalProps) {
  const [status, setStatus] = useState<GrievanceStatus>(grievance.status)
  const [resolutionNotes, setResolutionNotes] = useState(grievance.resolutionNotes || "")
  const [isUpdating, setIsUpdating] = useState(false)

  const handleUpdate = () => {
    setIsUpdating(true)

    const updates: Partial<Grievance> = {
      status,
      resolutionNotes: resolutionNotes || undefined,
    }

    if (status === "resolved") {
      updates.resolvedAt = new Date().toISOString()
    }

    updateGrievance(grievance.id, updates)

    setTimeout(() => {
      setIsUpdating(false)
      onClose()
    }, 500)
  }

  const getPriorityColor = (priority?: string) => {
    switch (priority) {
      case "critical":
        return "bg-red-500 text-white"
      case "high":
        return "bg-orange-500 text-white"
      case "medium":
        return "bg-yellow-500 text-white"
      case "low":
        return "bg-green-500 text-white"
      default:
        return "bg-gray-500 text-white"
    }
  }

  const getSentimentColor = (sentiment?: string) => {
    switch (sentiment) {
      case "very-negative":
        return "text-red-600"
      case "negative":
        return "text-orange-600"
      case "neutral":
        return "text-gray-600"
      case "positive":
        return "text-blue-600"
      case "very-positive":
        return "text-green-600"
      default:
        return "text-gray-600"
    }
  }

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">{grievance.title}</DialogTitle>
          <DialogDescription>Grievance ID: {grievance.id}</DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          <div className="flex flex-wrap gap-2">
            <Badge className={getPriorityColor(grievance.priority)} variant="secondary">
              {grievance.priority || "N/A"} Priority
            </Badge>
            {grievance.category && (
              <Badge variant="outline" className="capitalize">
                {grievance.category.replace(/-/g, " ")}
              </Badge>
            )}
          </div>

          <Separator />

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-1">
              <p className="text-sm font-medium text-muted-foreground">Submitted By</p>
              <p className="font-medium">{grievance.citizenName}</p>
              <p className="text-sm text-muted-foreground">{grievance.citizenEmail}</p>
            </div>

            <div className="space-y-1">
              <p className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                Submitted On
              </p>
              <p>{format(new Date(grievance.createdAt), "PPP 'at' p")}</p>
            </div>

            {grievance.location && (
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  Location
                </p>
                <p>{grievance.location}</p>
              </div>
            )}

            {grievance.resolvedAt && (
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Resolved On</p>
                <p>{format(new Date(grievance.resolvedAt), "PPP")}</p>
              </div>
            )}
          </div>

          <Separator />

          <div>
            <p className="text-sm font-medium text-muted-foreground mb-2">Description</p>
            <p className="text-sm leading-relaxed whitespace-pre-wrap">{grievance.description}</p>
          </div>

          {grievance.attachments && grievance.attachments.length > 0 && (
            <>
              <Separator />
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-2 flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  Attachments ({grievance.attachments.length})
                </p>
                <div className="space-y-2">
                  {grievance.attachments.map((file) => (
                    <div key={file.id} className="flex items-center justify-between rounded-lg bg-muted p-3">
                      <div>
                        <p className="text-sm font-medium">{file.name}</p>
                        <p className="text-xs text-muted-foreground">{(file.size / 1024).toFixed(2)} KB</p>
                      </div>
                      <Button variant="outline" size="sm">
                        View
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {grievance.voiceNote && (
            <>
              <Separator />
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-2 flex items-center gap-2">
                  <Mic className="h-4 w-4" />
                  Voice Note
                </p>
                <div className="rounded-lg bg-muted p-3">
                  <p className="text-sm font-medium">Duration: {grievance.voiceNote.duration} seconds</p>
                  {grievance.voiceNote.transcription && (
                    <p className="text-sm text-muted-foreground mt-2">
                      Transcription: {grievance.voiceNote.transcription}
                    </p>
                  )}
                </div>
              </div>
            </>
          )}

          {grievance.aiAnalysis && (
            <>
              <Separator />
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-3 flex items-center gap-2">
                  <Brain className="h-4 w-4" />
                  AI Analysis
                </p>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="rounded-lg bg-muted p-3">
                    <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                      <Target className="h-3 w-3" />
                      Suggested Department
                    </p>
                    <p className="font-medium">{grievance.aiAnalysis.suggestedDepartment}</p>
                  </div>

                  <div className="rounded-lg bg-muted p-3">
                    <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                      <TrendingUp className="h-3 w-3" />
                      Estimated Resolution
                    </p>
                    <p className="font-medium">{grievance.aiAnalysis.estimatedResolutionDays} days</p>
                  </div>

                  <div className="rounded-lg bg-muted p-3">
                    <p className="text-xs text-muted-foreground mb-1">Sentiment</p>
                    <p className={`font-medium capitalize ${getSentimentColor(grievance.aiAnalysis.sentiment)}`}>
                      {grievance.aiAnalysis.sentiment.replace(/-/g, " ")}
                    </p>
                  </div>

                  <div className="rounded-lg bg-muted p-3">
                    <p className="text-xs text-muted-foreground mb-1">AI Confidence</p>
                    <p className="font-medium">{Math.round(grievance.aiAnalysis.confidence * 100)}%</p>
                  </div>
                </div>

                {grievance.aiAnalysis.keywords.length > 0 && (
                  <div className="mt-3">
                    <p className="text-xs text-muted-foreground mb-2">Keywords</p>
                    <div className="flex flex-wrap gap-2">
                      {grievance.aiAnalysis.keywords.map((keyword, i) => (
                        <Badge key={i} variant="secondary">
                          {keyword}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </>
          )}

          <Separator />

          <div className="space-y-4">
            <div>
              <Label htmlFor="status">Update Status</Label>
              <Select value={status} onValueChange={(value) => setStatus(value as GrievanceStatus)}>
                <SelectTrigger id="status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="in-review">In Review</SelectItem>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                  <SelectItem value="resolved">Resolved</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="notes">Resolution Notes</Label>
              <Textarea
                id="notes"
                placeholder="Add notes about the resolution or progress..."
                value={resolutionNotes}
                onChange={(e) => setResolutionNotes(e.target.value)}
                rows={4}
              />
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleUpdate} disabled={isUpdating}>
            {isUpdating ? "Updating..." : "Update Grievance"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
