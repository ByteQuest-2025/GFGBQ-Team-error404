"use client"

import type React from "react"

import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { LogOut, LayoutDashboard, FileText, BarChart3, Home } from "lucide-react"
import { logout } from "@/lib/auth"
import type { UserRole } from "@/lib/types"

interface DashboardLayoutProps {
  children: React.ReactNode
  title: string
  userName: string
  userRole: UserRole
}

export function DashboardLayout({ children, title, userName, userRole }: DashboardLayoutProps) {
  const router = useRouter()

  const handleLogout = () => {
    logout()
    router.push("/login")
  }

  const navigation =
    userRole === "admin"
      ? [
          { name: "Dashboard", href: "/admin", icon: LayoutDashboard },
          { name: "Grievances", href: "/admin/grievances", icon: FileText },
          { name: "Analytics", href: "/admin/analytics", icon: BarChart3 },
        ]
      : [
          { name: "Dashboard", href: "/dashboard", icon: Home },
          { name: "Submit Grievance", href: "/submit", icon: FileText },
        ]

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-6">
            <h1 className="text-xl font-bold">Grievance Portal</h1>
            <nav className="hidden md:flex items-center gap-4">
              {navigation.map((item) => (
                <Button
                  key={item.name}
                  variant="ghost"
                  size="sm"
                  onClick={() => router.push(item.href)}
                  className="gap-2"
                >
                  <item.icon className="h-4 w-4" />
                  {item.name}
                </Button>
              ))}
            </nav>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden sm:block text-sm">
              <p className="font-medium">{userName}</p>
              <p className="text-xs text-muted-foreground capitalize">{userRole}</p>
            </div>
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 container py-6">
        <div className="mb-6">
          <h2 className="text-3xl font-bold tracking-tight">{title}</h2>
        </div>
        {children}
      </main>

      <footer className="border-t bg-muted/50 py-6">
        <div className="container text-center text-sm text-muted-foreground">
          <p>Powered by AI-driven Grievance Analysis System</p>
        </div>
      </footer>
    </div>
  )
}
