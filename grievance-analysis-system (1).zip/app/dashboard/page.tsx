"use client"

import { AuthGuard } from "@/components/auth-guard"
import { DashboardLayout } from "@/components/dashboard-layout"
import { GrievanceList } from "@/components/grievance-list"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { getGrievancesByUserId } from "@/lib/grievance-storage"
import { getCurrentUser } from "@/lib/auth"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import type { Grievance } from "@/lib/types"
import { Plus, FileText, Clock, CheckCircle2 } from "lucide-react"

export default function CitizenDashboard() {
  return (
    <AuthGuard requiredRole="citizen">
      <DashboardContent />
    </AuthGuard>
  )
}

function DashboardContent() {
  const router = useRouter()
  const [grievances, setGrievances] = useState<Grievance[]>([])
  const [user, setUser] = useState<ReturnType<typeof getCurrentUser>>(null)

  useEffect(() => {
    const currentUser = getCurrentUser()
    setUser(currentUser)

    if (currentUser) {
      const userGrievances = getGrievancesByUserId(currentUser.id)
      setGrievances(userGrievances)
    }
  }, [])

  const stats = {
    total: grievances.length,
    pending: grievances.filter((g) => g.status === "pending").length,
    inProgress: grievances.filter((g) => g.status === "in-progress" || g.status === "in-review").length,
    resolved: grievances.filter((g) => g.status === "resolved").length,
  }

  return (
    <DashboardLayout title="My Dashboard" userName={user?.name || ""} userRole="citizen">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">Welcome back, {user?.name}</h2>
            <p className="text-muted-foreground">Track and manage your grievances</p>
          </div>
          <Button onClick={() => router.push("/submit")} size="lg">
            <Plus className="mr-2 h-4 w-4" />
            Submit New Grievance
          </Button>
        </div>

        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Grievances</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending</CardTitle>
              <Clock className="h-4 w-4 text-amber-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.pending}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">In Progress</CardTitle>
              <Clock className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.inProgress}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Resolved</CardTitle>
              <CheckCircle2 className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.resolved}</div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>My Grievances</CardTitle>
            <CardDescription>View and track the status of your submitted grievances</CardDescription>
          </CardHeader>
          <CardContent>
            <GrievanceList grievances={grievances} showCitizenInfo={false} />
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
