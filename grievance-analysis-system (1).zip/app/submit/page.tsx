"use client"

import { AuthGuard } from "@/components/auth-guard"
import { DashboardLayout } from "@/components/dashboard-layout"
import { SubmitGrievanceForm } from "@/components/submit-grievance-form"
import { getCurrentUser } from "@/lib/auth"
import { useState, useEffect } from "react"

export default function SubmitGrievancePage() {
  return (
    <AuthGuard requiredRole="citizen">
      <SubmitContent />
    </AuthGuard>
  )
}

function SubmitContent() {
  const [user, setUser] = useState<ReturnType<typeof getCurrentUser>>(null)

  useEffect(() => {
    setUser(getCurrentUser())
  }, [])

  return (
    <DashboardLayout title="Submit Grievance" userName={user?.name || ""} userRole="citizen">
      <SubmitGrievanceForm />
    </DashboardLayout>
  )
}
