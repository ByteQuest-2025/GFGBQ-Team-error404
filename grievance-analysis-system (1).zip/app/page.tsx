"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Hexagon, ArrowRight, Zap, Shield, BarChart3, Users, Clock, FileCheck, Star, ChevronDown } from "lucide-react"
import { useState } from "react"

export default function Home() {
  const [openFaq, setOpenFaq] = useState<number | null>(null)

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 group">
            <div className="h-10 w-10 bg-primary rounded flex items-center justify-center transition-transform group-hover:scale-110">
              <Hexagon className="h-6 w-6 text-primary-foreground fill-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-foreground">GrievAi</h1>
            </div>
          </Link>
          <nav className="hidden md:flex items-center gap-8">
            <Link href="#features" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Features
            </Link>
            <Link href="#about" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              About
            </Link>
            <Link href="/login" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Login
            </Link>
            <Button size="sm" className="bg-primary hover:bg-primary/90 text-primary-foreground" asChild>
              <Link href="/register">Get Started</Link>
            </Button>
          </nav>
        </div>
      </header>

      <section className="relative hex-pattern py-20 md:py-32">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-background/50 to-background" />

        <div className="container mx-auto px-6 relative">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-primary/10 border border-primary/20 rounded-full text-sm text-primary mb-8">
              <Zap className="h-3.5 w-3.5" />
              AI-Powered Civic Platform
            </div>

            <h2 className="text-5xl md:text-6xl lg:text-7xl font-bold text-foreground mb-6 text-balance leading-tight">
              Run Civic Governance
              <br />
              <span className="text-primary">Everywhere</span>
            </h2>

            <p className="text-xl text-muted-foreground mb-10 text-pretty max-w-2xl mx-auto leading-relaxed">
              GrievAi® is a free, open-source, AI-powered civic platform that lets government bodies manage citizen
              complaints, analyze patterns, and deliver faster resolutions.
            </p>

            <div className="flex gap-4 justify-center flex-wrap mb-16">
              <Button
                size="lg"
                className="h-12 px-8 bg-primary hover:bg-primary/90 text-primary-foreground glow-green"
                asChild
              >
                <Link href="/register">
                  Submit Grievance <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="h-12 px-8 border-border hover:bg-card bg-transparent"
                asChild
              >
                <Link href="/login">Admin Portal</Link>
              </Button>
            </div>

            <div className="grid grid-cols-3 gap-8 max-w-2xl mx-auto">
              <div className="border border-border bg-card/50 rounded-lg p-6 backdrop-blur-sm">
                <div className="text-3xl font-bold text-primary mb-1">10K+</div>
                <div className="text-sm text-muted-foreground">Processed</div>
              </div>
              <div className="border border-border bg-card/50 rounded-lg p-6 backdrop-blur-sm">
                <div className="text-3xl font-bold text-primary mb-1">95%</div>
                <div className="text-sm text-muted-foreground">Resolved</div>
              </div>
              <div className="border border-border bg-card/50 rounded-lg p-6 backdrop-blur-sm">
                <div className="text-3xl font-bold text-primary mb-1">24h</div>
                <div className="text-sm text-muted-foreground">Avg Time</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="features" className="py-20 bg-background">
        <div className="container mx-auto px-6">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h3 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                Learn what GrievAi is able to offer
              </h3>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Advanced AI capabilities meet efficient civic service delivery
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card className="p-6 bg-card border border-border hover:border-primary/50 transition-all group">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <Zap className="h-6 w-6 text-primary" />
                </div>
                <h4 className="text-lg font-semibold text-foreground mb-2">AI Auto-Categorization</h4>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Automatically classify complaints by department using GPT-powered analysis. Infrastructure, Health,
                  Education - sorted instantly.
                </p>
              </Card>

              <Card className="p-6 bg-card border border-border hover:border-primary/50 transition-all group">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <Clock className="h-6 w-6 text-primary" />
                </div>
                <h4 className="text-lg font-semibold text-foreground mb-2">Smart Prioritization</h4>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Critical issues flagged automatically based on urgency, sentiment analysis, and potential impact on
                  citizens.
                </p>
              </Card>

              <Card className="p-6 bg-card border border-border hover:border-primary/50 transition-all group">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <BarChart3 className="h-6 w-6 text-primary" />
                </div>
                <h4 className="text-lg font-semibold text-foreground mb-2">Analytics Dashboard</h4>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Real-time insights with trend analysis, sentiment tracking, and AI-generated recommendations for
                  authorities.
                </p>
              </Card>

              <Card className="p-6 bg-card border border-border hover:border-primary/50 transition-all group">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <FileCheck className="h-6 w-6 text-primary" />
                </div>
                <h4 className="text-lg font-semibold text-foreground mb-2">Multi-Modal Submission</h4>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Submit via text, voice notes, or file attachments. Maximum accessibility for all citizens.
                </p>
              </Card>

              <Card className="p-6 bg-card border border-border hover:border-primary/50 transition-all group">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <h4 className="text-lg font-semibold text-foreground mb-2">Citizen Portal</h4>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Track your grievances in real-time with live status updates and transparent resolution timelines.
                </p>
              </Card>

              <Card className="p-6 bg-card border border-border hover:border-primary/50 transition-all group">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <Shield className="h-6 w-6 text-primary" />
                </div>
                <h4 className="text-lg font-semibold text-foreground mb-2">Secure & Accountable</h4>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Role-based access control with complete audit trails. Data security and accountability built-in.
                </p>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-card/30">
        <div className="container mx-auto px-6">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h3 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                Trusted by Citizens & Administrators
              </h3>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Real experiences from people using GrievAi to improve civic services
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              <Card className="p-6 bg-card border border-border hover:border-primary/50 transition-all">
                <div className="flex gap-1 mb-4">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className="h-4 w-4 fill-primary text-primary" />
                  ))}
                </div>
                <p className="text-muted-foreground mb-4 leading-relaxed">
                  "Finally got my street light issue resolved in 48 hours! The AI categorization made sure my complaint
                  reached the right department immediately."
                </p>
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-sm font-semibold text-primary">RP</span>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">Rajesh Patel</p>
                    <p className="text-xs text-muted-foreground">Citizen, Mumbai</p>
                  </div>
                </div>
              </Card>

              <Card className="p-6 bg-card border border-border hover:border-primary/50 transition-all">
                <div className="flex gap-1 mb-4">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className="h-4 w-4 fill-primary text-primary" />
                  ))}
                </div>
                <p className="text-muted-foreground mb-4 leading-relaxed">
                  "As an admin, the analytics dashboard gives me insights I never had before. We've reduced resolution
                  time by 40% in just 3 months."
                </p>
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-sm font-semibold text-primary">SK</span>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">Sunita Kumar</p>
                    <p className="text-xs text-muted-foreground">Municipal Officer, Pune</p>
                  </div>
                </div>
              </Card>

              <Card className="p-6 bg-card border border-border hover:border-primary/50 transition-all">
                <div className="flex gap-1 mb-4">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className="h-4 w-4 fill-primary text-primary" />
                  ))}
                </div>
                <p className="text-muted-foreground mb-4 leading-relaxed">
                  "The voice recording feature is a game-changer. My elderly parents can now submit complaints without
                  typing. Truly inclusive."
                </p>
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-sm font-semibold text-primary">AM</span>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">Anil Mehta</p>
                    <p className="text-xs text-muted-foreground">Citizen, Delhi</p>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-background">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-16">
              <h3 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Frequently Asked Questions</h3>
              <p className="text-muted-foreground">Everything you need to know about GrievAi</p>
            </div>

            <div className="space-y-4">
              {[
                {
                  question: "How does AI categorization work?",
                  answer:
                    "Our AI uses advanced natural language processing powered by GPT to analyze the content of your grievance and automatically categorize it by department (Infrastructure, Health, Education, etc.) and assess its priority level based on urgency indicators and sentiment.",
                },
                {
                  question: "Is my data secure and private?",
                  answer:
                    "Absolutely. We use industry-standard encryption for all data transmission and storage. Your personal information is never shared without consent, and all admin access is logged for complete accountability and transparency.",
                },
                {
                  question: "Can I submit grievances anonymously?",
                  answer:
                    "Currently, we require user accounts to track grievances and provide status updates. However, your personal information is only visible to authorized government officials handling your specific complaint.",
                },
                {
                  question: "How long does it take to resolve a grievance?",
                  answer:
                    "Resolution times vary by category and priority. On average, high-priority issues are addressed within 24-48 hours, while standard grievances typically resolve within 7-10 days. You can track real-time status updates in your citizen dashboard.",
                },
                {
                  question: "What types of files can I attach?",
                  answer:
                    "You can attach images (JPG, PNG), documents (PDF), and record voice notes directly in the submission form. This helps provide evidence and context for your grievance, leading to faster and more accurate resolutions.",
                },
                {
                  question: "Can I reopen a closed grievance?",
                  answer:
                    "Yes, if you're not satisfied with the resolution, you can add comments or reopen the grievance from your dashboard. The system will flag it for administrator review and potentially escalate based on your feedback.",
                },
              ].map((faq, index) => (
                <Card
                  key={index}
                  className="bg-card border border-border overflow-hidden hover:border-primary/50 transition-all cursor-pointer"
                  onClick={() => setOpenFaq(openFaq === index ? null : index)}
                >
                  <div className="p-6">
                    <div className="flex items-center justify-between">
                      <h4 className="text-lg font-semibold text-foreground pr-4">{faq.question}</h4>
                      <ChevronDown
                        className={`h-5 w-5 text-muted-foreground transition-transform flex-shrink-0 ${
                          openFaq === index ? "rotate-180" : ""
                        }`}
                      />
                    </div>
                    {openFaq === index && <p className="text-muted-foreground mt-4 leading-relaxed">{faq.answer}</p>}
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="about" className="py-20 bg-background">
        <div className="container mx-auto px-6">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h3 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Meet the Alumni</h3>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Built by innovators passionate about transforming civic governance through AI
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="p-6 bg-card border border-border hover:border-primary/50 transition-all group text-center">
                <div className="h-20 w-20 rounded-full bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center mx-auto mb-4 group-hover:from-primary/30 group-hover:to-primary/20 transition-all">
                  <span className="text-2xl font-bold text-primary">OR</span>
                </div>
                <h4 className="text-lg font-semibold text-foreground mb-1">Ojas Rao</h4>
                <p className="text-sm text-muted-foreground">Alumni</p>
              </Card>

              <Card className="p-6 bg-card border border-border hover:border-primary/50 transition-all group text-center">
                <div className="h-20 w-20 rounded-full bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center mx-auto mb-4 group-hover:from-primary/30 group-hover:to-primary/20 transition-all">
                  <span className="text-2xl font-bold text-primary">AA</span>
                </div>
                <h4 className="text-lg font-semibold text-foreground mb-1">Arjun Albenkar</h4>
                <p className="text-sm text-muted-foreground">Alumni</p>
              </Card>

              <Card className="p-6 bg-card border border-border hover:border-primary/50 transition-all group text-center">
                <div className="h-20 w-20 rounded-full bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center mx-auto mb-4 group-hover:from-primary/30 group-hover:to-primary/20 transition-all">
                  <span className="text-2xl font-bold text-primary">KC</span>
                </div>
                <h4 className="text-lg font-semibold text-foreground mb-1">Krish Chabbrani</h4>
                <p className="text-sm text-muted-foreground">Alumni</p>
              </Card>

              <Card className="p-6 bg-card border border-border hover:border-primary/50 transition-all group text-center">
                <div className="h-20 w-20 rounded-full bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center mx-auto mb-4 group-hover:from-primary/30 group-hover:to-primary/20 transition-all">
                  <span className="text-2xl font-bold text-primary">SA</span>
                </div>
                <h4 className="text-lg font-semibold text-foreground mb-1">Shivansh Agrawal</h4>
                <p className="text-sm text-muted-foreground">Alumni</p>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-6">
          <Card className="max-w-4xl mx-auto bg-primary/5 border-primary/20 border-2 p-12 text-center">
            <h3 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Ready to transform civic governance?
            </h3>
            <p className="text-muted-foreground mb-8 text-lg max-w-2xl mx-auto leading-relaxed">
              Join thousands using GrievAi to build more responsive, accountable, and efficient public services.
            </p>
            <div className="flex gap-4 justify-center flex-wrap">
              <Button
                size="lg"
                className="h-12 px-8 bg-primary hover:bg-primary/90 text-primary-foreground glow-green"
                asChild
              >
                <Link href="/register">
                  Get Started <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="h-12 px-8 border-border hover:bg-card bg-transparent"
                asChild
              >
                <Link href="/login">Admin Access</Link>
              </Button>
            </div>
          </Card>
        </div>
      </section>

      <footer className="border-t border-border bg-card/30 backdrop-blur-sm">
        <div className="container mx-auto px-6 py-12">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-3">
              <div className="h-8 w-8 bg-primary rounded flex items-center justify-center">
                <Hexagon className="h-5 w-5 text-primary-foreground fill-primary-foreground" />
              </div>
              <span className="text-sm text-muted-foreground">
                © 2025 GrievAi. Built with AI to serve citizens better.
              </span>
            </div>
            <div className="flex gap-6">
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Documentation
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Support
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Privacy
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
