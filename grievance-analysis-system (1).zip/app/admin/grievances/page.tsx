"use client"

import { AuthGuard } from "@/components/auth-guard"
import { DashboardLayout } from "@/components/dashboard-layout"
import { GrievanceList } from "@/components/grievance-list"
import { GrievanceDetailModal } from "@/components/grievance-detail-modal"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { getGrievances } from "@/lib/grievance-storage"
import { getCurrentUser } from "@/lib/auth"
import { useEffect, useState } from "react"
import type { Grievance } from "@/lib/types"
import { Search } from "lucide-react"

export default function AdminGrievancesPage() {
  return (
    <AuthGuard requiredRole="admin">
      <AdminGrievancesContent />
    </AuthGuard>
  )
}

function AdminGrievancesContent() {
  const [grievances, setGrievances] = useState<Grievance[]>([])
  const [filteredGrievances, setFilteredGrievances] = useState<Grievance[]>([])
  const [selectedGrievance, setSelectedGrievance] = useState<Grievance | null>(null)
  const [user, setUser] = useState<ReturnType<typeof getCurrentUser>>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [categoryFilter, setCategoryFilter] = useState<string>("all")
  const [priorityFilter, setPriorityFilter] = useState<string>("all")

  useEffect(() => {
    setUser(getCurrentUser())
    loadGrievances()
  }, [])

  const loadGrievances = () => {
    const allGrievances = getGrievances()
    setGrievances(allGrievances)
    setFilteredGrievances(allGrievances)
  }

  useEffect(() => {
    let filtered = grievances

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(
        (g) =>
          g.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          g.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
          g.citizenName.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // Status filter
    if (statusFilter !== "all") {
      filtered = filtered.filter((g) => g.status === statusFilter)
    }

    // Category filter
    if (categoryFilter !== "all") {
      filtered = filtered.filter((g) => g.category === categoryFilter)
    }

    // Priority filter
    if (priorityFilter !== "all") {
      filtered = filtered.filter((g) => g.priority === priorityFilter)
    }

    setFilteredGrievances(filtered)
  }, [searchTerm, statusFilter, categoryFilter, priorityFilter, grievances])

  const handleGrievanceClick = (grievance: Grievance) => {
    setSelectedGrievance(grievance)
  }

  const handleCloseModal = () => {
    setSelectedGrievance(null)
    loadGrievances() // Reload to get updates
  }

  return (
    <DashboardLayout title="Manage Grievances" userName={user?.name || ""} userRole="admin">
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search grievances..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full md:w-[180px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="in-review">In Review</SelectItem>
              <SelectItem value="in-progress">In Progress</SelectItem>
              <SelectItem value="resolved">Resolved</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>

          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-full md:w-[200px]">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="civic-infrastructure">Civic Infrastructure</SelectItem>
              <SelectItem value="sanitation">Sanitation</SelectItem>
              <SelectItem value="public-safety">Public Safety</SelectItem>
              <SelectItem value="utilities">Utilities</SelectItem>
              <SelectItem value="healthcare">Healthcare</SelectItem>
              <SelectItem value="education">Education</SelectItem>
              <SelectItem value="administrative">Administrative</SelectItem>
            </SelectContent>
          </Select>

          <Select value={priorityFilter} onValueChange={setPriorityFilter}>
            <SelectTrigger className="w-full md:w-[180px]">
              <SelectValue placeholder="Priority" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Priorities</SelectItem>
              <SelectItem value="critical">Critical</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="low">Low</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="text-sm text-muted-foreground">
          Showing {filteredGrievances.length} of {grievances.length} grievances
        </div>

        <GrievanceList grievances={filteredGrievances} showCitizenInfo={true} onGrievanceClick={handleGrievanceClick} />
      </div>

      {selectedGrievance && <GrievanceDetailModal grievance={selectedGrievance} onClose={handleCloseModal} />}
    </DashboardLayout>
  )
}
