"use client"

import type { Grievance } from "@/lib/types"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { formatDistanceToNow } from "date-fns"
import { FileText, Clock, AlertCircle, Copy } from "lucide-react"
import React from "react"
import { StatusProgress } from "@/components/status-progress"

interface GrievanceListProps {
  grievances: Grievance[]
  showCitizenInfo?: boolean
  onGrievanceClick?: (grievance: Grievance) => void
}

export function GrievanceList({ grievances, showCitizenInfo = false, onGrievanceClick }: GrievanceListProps) {
  const [copiedId, setCopiedId] = React.useState<string | null>(null)

  const copyTrackingId = (id: string, e: React.MouseEvent) => {
    e.stopPropagation()
    navigator.clipboard.writeText(id)
    setCopiedId(id)
    setTimeout(() => setCopiedId(null), 2000)
  }

  if (grievances.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <FileText className="h-12 w-12 text-muted-foreground mb-4" />
        <h3 className="text-lg font-semibold">No grievances found</h3>
        <p className="text-sm text-muted-foreground">Start by submitting your first grievance</p>
      </div>
    )
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-amber-100 text-amber-800 border-amber-200"
      case "in-review":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "in-progress":
        return "bg-purple-100 text-purple-800 border-purple-200"
      case "resolved":
        return "bg-green-100 text-green-800 border-green-200"
      case "rejected":
        return "bg-red-100 text-red-800 border-red-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getPriorityColor = (priority?: string) => {
    switch (priority) {
      case "critical":
        return "bg-red-500 text-white"
      case "high":
        return "bg-orange-500 text-white"
      case "medium":
        return "bg-yellow-500 text-white"
      case "low":
        return "bg-green-500 text-white"
      default:
        return "bg-gray-500 text-white"
    }
  }

  return (
    <div className="space-y-3">
      {grievances.map((grievance) => (
        <Card
          key={grievance.id}
          className={`transition-all ${onGrievanceClick ? "cursor-pointer hover:shadow-md" : ""}`}
          onClick={() => onGrievanceClick?.(grievance)}
        >
          <CardContent className="p-4">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs text-muted-foreground font-mono">ID: {grievance.id}</span>
                  <button
                    onClick={(e) => copyTrackingId(grievance.id, e)}
                    className="text-muted-foreground hover:text-foreground transition-colors"
                    title="Copy tracking ID"
                  >
                    <Copy className="h-3 w-3" />
                  </button>
                  {copiedId === grievance.id && <span className="text-xs text-green-600">Copied!</span>}
                </div>
                <div className="flex items-center gap-2 mb-2">
                  <h4 className="font-semibold truncate">{grievance.title}</h4>
                  {grievance.priority && (
                    <Badge className={getPriorityColor(grievance.priority)} variant="secondary">
                      {grievance.priority}
                    </Badge>
                  )}
                </div>

                <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{grievance.description}</p>

                <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                  {showCitizenInfo && (
                    <span className="flex items-center gap-1">
                      <strong>From:</strong> {grievance.citizenName}
                    </span>
                  )}

                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {formatDistanceToNow(new Date(grievance.createdAt), { addSuffix: true })}
                  </span>

                  {grievance.category && <span className="capitalize">{grievance.category.replace(/-/g, " ")}</span>}

                  {grievance.aiAnalysis && (
                    <span className="flex items-center gap-1">
                      <AlertCircle className="h-3 w-3" />
                      AI: {Math.round(grievance.aiAnalysis.confidence * 100)}% confident
                    </span>
                  )}
                </div>

                <div className="mt-3 pt-3 border-t">
                  <StatusProgress currentStatus={grievance.status} size="sm" showLabels={false} />
                </div>
              </div>

              <Badge className={getStatusColor(grievance.status)} variant="outline">
                {grievance.status.replace(/-/g, " ")}
              </Badge>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
