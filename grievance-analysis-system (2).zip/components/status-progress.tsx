"use client"

import { CheckCircle2, Clock, AlertCircle, FileText } from "lucide-react"

interface StatusProgressProps {
  currentStatus: string
  size?: "sm" | "md" | "lg"
  showLabels?: boolean
}

export function StatusProgress({ currentStatus, size = "md", showLabels = true }: StatusProgressProps) {
  const steps = [
    { status: "pending", label: "Submitted", icon: FileText },
    { status: "in-review", label: "In Review", icon: Clock },
    { status: "in-progress", label: "In Progress", icon: AlertCircle },
    { status: "resolved", label: "Resolved", icon: CheckCircle2 },
  ]

  const getStepIndex = (status: string) => {
    const index = steps.findIndex((s) => s.status === status)
    return index === -1 ? 0 : index
  }

  const currentIndex = getStepIndex(currentStatus)
  const isRejected = currentStatus === "rejected"

  const sizeClasses = {
    sm: {
      circle: "h-6 w-6",
      icon: "h-3 w-3",
      line: "h-0.5",
      text: "text-xs",
    },
    md: {
      circle: "h-8 w-8",
      icon: "h-4 w-4",
      line: "h-1",
      text: "text-sm",
    },
    lg: {
      circle: "h-10 w-10",
      icon: "h-5 w-5",
      line: "h-1",
      text: "text-base",
    },
  }

  const classes = sizeClasses[size]

  if (isRejected) {
    return (
      <div className="flex items-center justify-center gap-2 p-4 bg-red-50 dark:bg-red-950/20 rounded-lg border border-red-200 dark:border-red-900">
        <div className="h-8 w-8 rounded-full bg-red-500 flex items-center justify-center">
          <AlertCircle className="h-4 w-4 text-white" />
        </div>
        <span className="font-medium text-red-700 dark:text-red-400">Complaint Rejected</span>
      </div>
    )
  }

  return (
    <div className="w-full">
      <div className="flex items-center justify-between relative">
        {steps.map((step, index) => {
          const isCompleted = index <= currentIndex
          const isCurrent = index === currentIndex
          const Icon = step.icon

          return (
            <div key={step.status} className="flex flex-col items-center relative flex-1">
              {/* Connection Line */}
              {index > 0 && (
                <div
                  className={`absolute top-4 right-1/2 w-full ${classes.line} ${
                    index <= currentIndex ? "bg-primary" : "bg-muted"
                  } transition-all duration-300`}
                  style={{ transform: "translateY(-50%)" }}
                />
              )}

              {/* Step Circle */}
              <div
                className={`relative z-10 ${classes.circle} rounded-full flex items-center justify-center transition-all duration-300 ${
                  isCompleted
                    ? "bg-primary text-primary-foreground shadow-lg"
                    : "bg-muted text-muted-foreground border-2 border-muted"
                } ${isCurrent ? "ring-4 ring-primary/20 scale-110" : ""}`}
              >
                <Icon className={classes.icon} />

                {/* Pulse animation for current step */}
                {isCurrent && <span className="absolute inset-0 rounded-full bg-primary animate-ping opacity-20" />}
              </div>

              {/* Step Label */}
              {showLabels && (
                <span
                  className={`mt-2 ${classes.text} font-medium text-center ${
                    isCompleted ? "text-foreground" : "text-muted-foreground"
                  } transition-colors duration-300`}
                >
                  {step.label}
                </span>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
