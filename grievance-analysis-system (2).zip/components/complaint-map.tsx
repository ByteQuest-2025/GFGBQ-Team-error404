"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { Grievance } from "@/lib/types"
import { MapPin, AlertTriangle } from "lucide-react"
import { useState } from "react"

interface ComplaintMapProps {
  grievances: Grievance[]
  showTitle?: boolean
}

// Simulated city areas with coordinates (in a grid system)
const cityAreas = [
  { id: "north", name: "North Zone", x: 50, y: 15, districts: ["Sector 1", "Sector 2", "Sector 3"] },
  { id: "south", name: "South Zone", x: 50, y: 85, districts: ["Sector 7", "Sector 8", "Sector 9"] },
  { id: "east", name: "East Zone", x: 85, y: 50, districts: ["Sector 4", "Sector 5"] },
  { id: "west", name: "West Zone", x: 15, y: 50, districts: ["Sector 10", "Sector 11"] },
  { id: "central", name: "Central Zone", x: 50, y: 50, districts: ["Downtown", "City Center"] },
  { id: "northeast", name: "Northeast Zone", x: 75, y: 25, districts: ["Sector 6", "Industrial Area"] },
  { id: "northwest", name: "Northwest Zone", x: 25, y: 25, districts: ["Sector 12", "Tech Park"] },
  { id: "southeast", name: "Southeast Zone", x: 75, y: 75, districts: ["Sector 13", "Residential Complex"] },
  { id: "southwest", name: "Southwest Zone", x: 25, y: 75, districts: ["Sector 14", "Market District"] },
]

export function ComplaintMap({ grievances, showTitle = true }: ComplaintMapProps) {
  const [selectedArea, setSelectedArea] = useState<string | null>(null)

  // Generate complaint clusters by area
  const complaintClusters = cityAreas.map((area) => {
    // Randomly assign grievances to areas based on their location or randomly if not specified
    const areaGrievances = grievances.filter((g) => {
      if (g.location) {
        return area.districts.some((d) => g.location?.toLowerCase().includes(d.toLowerCase()))
      }
      // Random distribution for demo
      return Math.random() > 0.7
    })

    const critical = areaGrievances.filter((g) => g.priority === "critical").length
    const high = areaGrievances.filter((g) => g.priority === "high").length
    const medium = areaGrievances.filter((g) => g.priority === "medium").length
    const low = areaGrievances.filter((g) => g.priority === "low").length
    const total = areaGrievances.length

    // Determine cluster color based on severity
    let color = "rgb(34, 197, 94)" // green (low)
    let intensity = 0.3

    if (critical > 0) {
      color = "rgb(239, 68, 68)" // red
      intensity = 0.8 + Math.min(critical * 0.1, 0.2)
    } else if (high > 0) {
      color = "rgb(249, 115, 22)" // orange
      intensity = 0.6 + Math.min(high * 0.1, 0.3)
    } else if (medium > 0) {
      color = "rgb(234, 179, 8)" // yellow
      intensity = 0.4 + Math.min(medium * 0.1, 0.3)
    }

    return {
      ...area,
      grievances: areaGrievances,
      total,
      critical,
      high,
      medium,
      low,
      color,
      intensity,
    }
  })

  const selectedCluster = complaintClusters.find((c) => c.id === selectedArea)

  return (
    <Card className="w-full">
      {showTitle && (
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            Complaint Density Map
          </CardTitle>
          <CardDescription>
            Geographic distribution of complaints across city zones. Larger and redder markers indicate higher severity.
          </CardDescription>
        </CardHeader>
      )}
      <CardContent>
        <div className="space-y-4">
          {/* Map Visualization */}
          <div className="relative w-full aspect-square bg-slate-900 rounded-lg overflow-hidden border-2 border-slate-700">
            {/* Grid overlay */}
            <svg className="absolute inset-0 w-full h-full opacity-20">
              <defs>
                <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                  <path d="M 20 0 L 0 0 0 20" fill="none" stroke="currentColor" strokeWidth="0.5" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
            </svg>

            {/* City boundary */}
            <div className="absolute inset-4 border-2 border-primary/30 rounded" />

            {/* Complaint clusters */}
            {complaintClusters.map((cluster) => {
              if (cluster.total === 0) return null

              const size = 20 + Math.min(cluster.total * 8, 60)
              const isSelected = selectedArea === cluster.id

              return (
                <button
                  key={cluster.id}
                  className="absolute group transition-transform hover:scale-110 focus:outline-none focus:scale-110"
                  style={{
                    left: `${cluster.x}%`,
                    top: `${cluster.y}%`,
                    transform: "translate(-50%, -50%)",
                  }}
                  onClick={() => setSelectedArea(selectedArea === cluster.id ? null : cluster.id)}
                >
                  {/* Glow effect */}
                  <div
                    className="absolute inset-0 rounded-full blur-lg transition-opacity"
                    style={{
                      width: size,
                      height: size,
                      backgroundColor: cluster.color,
                      opacity: cluster.intensity * 0.5,
                    }}
                  />

                  {/* Main marker */}
                  <div
                    className={`relative rounded-full flex items-center justify-center transition-all ${
                      isSelected ? "ring-4 ring-white/50" : ""
                    }`}
                    style={{
                      width: size,
                      height: size,
                      backgroundColor: cluster.color,
                      opacity: cluster.intensity,
                    }}
                  >
                    <span className="text-white font-bold text-xs">{cluster.total}</span>
                  </div>

                  {/* Critical indicator */}
                  {cluster.critical > 0 && (
                    <div className="absolute -top-1 -right-1 bg-red-600 rounded-full p-1 animate-pulse">
                      <AlertTriangle className="h-3 w-3 text-white" />
                    </div>
                  )}

                  {/* Tooltip on hover */}
                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10">
                    <div className="bg-slate-800 text-white px-3 py-2 rounded-lg shadow-lg text-xs whitespace-nowrap">
                      <div className="font-semibold">{cluster.name}</div>
                      <div className="text-slate-300">{cluster.total} complaints</div>
                    </div>
                  </div>
                </button>
              )
            })}
          </div>

          {/* Legend */}
          <div className="flex flex-wrap items-center justify-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-red-500" />
              <span>Critical</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-orange-500" />
              <span>High</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-yellow-500" />
              <span>Medium</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-green-500" />
              <span>Low</span>
            </div>
          </div>

          {/* Selected area details */}
          {selectedCluster && (
            <Card className="bg-muted/50">
              <CardHeader>
                <CardTitle className="text-lg">{selectedCluster.name}</CardTitle>
                <CardDescription>Detailed breakdown of complaints in this zone</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-2xl font-bold">{selectedCluster.total}</div>
                    <div className="text-sm text-muted-foreground">Total Complaints</div>
                  </div>
                  <div className="space-y-2">
                    {selectedCluster.critical > 0 && (
                      <div className="flex items-center justify-between">
                        <Badge variant="destructive">Critical</Badge>
                        <span className="font-semibold">{selectedCluster.critical}</span>
                      </div>
                    )}
                    {selectedCluster.high > 0 && (
                      <div className="flex items-center justify-between">
                        <Badge className="bg-orange-500">High</Badge>
                        <span className="font-semibold">{selectedCluster.high}</span>
                      </div>
                    )}
                    {selectedCluster.medium > 0 && (
                      <div className="flex items-center justify-between">
                        <Badge className="bg-yellow-500">Medium</Badge>
                        <span className="font-semibold">{selectedCluster.medium}</span>
                      </div>
                    )}
                    {selectedCluster.low > 0 && (
                      <div className="flex items-center justify-between">
                        <Badge className="bg-green-500">Low</Badge>
                        <span className="font-semibold">{selectedCluster.low}</span>
                      </div>
                    )}
                  </div>
                </div>
                <div className="mt-4 text-sm text-muted-foreground">
                  <div className="font-semibold mb-1">Districts:</div>
                  <div>{selectedCluster.districts.join(", ")}</div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
