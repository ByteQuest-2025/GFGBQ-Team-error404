"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { getCurrentUser } from "@/lib/auth"
import { addGrievance } from "@/lib/grievance-storage"
import { analyzeGrievance } from "@/lib/ai-analysis"
import type { Grievance, FileAttachment, VoiceNote } from "@/lib/types"
import { Upload, Mic, Loader2, X } from "lucide-react"

export function SubmitGrievanceForm() {
  const router = useRouter()
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [location, setLocation] = useState("")
  const [attachments, setAttachments] = useState<FileAttachment[]>([])
  const [voiceNote, setVoiceNote] = useState<VoiceNote | null>(null)
  const [isRecording, setIsRecording] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    const newAttachments: FileAttachment[] = Array.from(files).map((file) => ({
      id: `file-${Date.now()}-${Math.random()}`,
      name: file.name,
      type: file.type,
      size: file.size,
      url: URL.createObjectURL(file),
    }))

    setAttachments([...attachments, ...newAttachments])
  }

  const removeAttachment = (id: string) => {
    setAttachments(attachments.filter((a) => a.id !== id))
  }

  const handleVoiceRecording = () => {
    if (isRecording) {
      // Stop recording
      setIsRecording(false)
      // Simulate voice note creation
      const mockVoiceNote: VoiceNote = {
        id: `voice-${Date.now()}`,
        duration: 30,
        url: "mock-voice-url",
        transcription:
          "This is a mock transcription of the voice note. The actual implementation would use Web Audio API.",
      }
      setVoiceNote(mockVoiceNote)
    } else {
      // Start recording
      setIsRecording(true)
      // In a real implementation, this would use the Web Audio API
      // For now, we'll just simulate it
    }
  }

  const removeVoiceNote = () => {
    setVoiceNote(null)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsSubmitting(true)

    if (!title || !description) {
      setError("Please fill in title and description")
      setIsSubmitting(false)
      return
    }

    const user = getCurrentUser()
    if (!user) {
      setError("User not authenticated")
      setIsSubmitting(false)
      return
    }

    try {
      // Analyze the grievance using AI
      const aiAnalysis = await analyzeGrievance(title, description, voiceNote?.transcription)

      const newGrievance: Grievance = {
        id: `grievance-${Date.now()}`,
        citizenId: user.id,
        citizenName: user.name,
        citizenEmail: user.email,
        title,
        description,
        category: aiAnalysis.category,
        status: "pending",
        priority: aiAnalysis.priority,
        aiAnalysis,
        attachments: attachments.length > 0 ? attachments : undefined,
        voiceNote: voiceNote || undefined,
        location: location || undefined,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }

      addGrievance(newGrievance)
      router.push("/dashboard")
    } catch (err) {
      setError("Failed to submit grievance. Please try again.")
      setIsSubmitting(false)
    }
  }

  return (
    <Card className="max-w-3xl mx-auto">
      <CardHeader>
        <CardTitle>Submit a New Grievance</CardTitle>
        <CardDescription>
          Provide detailed information about your issue. Our AI will automatically categorize and prioritize it.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="title">Title</Label>
            <Input
              id="title"
              placeholder="Brief summary of your grievance"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Provide detailed information about the issue..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
              rows={6}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="location">Location (Optional)</Label>
            <Input
              id="location"
              placeholder="e.g., Main Street, Ward 5, Delhi"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            />
          </div>

          <div className="space-y-4">
            <div>
              <Label>Attachments (Optional)</Label>
              <div className="mt-2">
                <label htmlFor="file-upload" className="cursor-pointer">
                  <div className="flex items-center gap-2 rounded-lg border-2 border-dashed p-4 hover:border-primary transition-colors">
                    <Upload className="h-5 w-5 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">Click to upload images or documents</span>
                  </div>
                  <input
                    id="file-upload"
                    type="file"
                    multiple
                    accept="image/*,.pdf,.doc,.docx"
                    className="hidden"
                    onChange={handleFileUpload}
                  />
                </label>
              </div>

              {attachments.length > 0 && (
                <div className="mt-3 space-y-2">
                  {attachments.map((file) => (
                    <div key={file.id} className="flex items-center justify-between rounded-lg bg-muted p-3">
                      <div className="flex items-center gap-3">
                        <div className="text-sm">
                          <p className="font-medium">{file.name}</p>
                          <p className="text-xs text-muted-foreground">{(file.size / 1024).toFixed(2)} KB</p>
                        </div>
                      </div>
                      <Button type="button" variant="ghost" size="sm" onClick={() => removeAttachment(file.id)}>
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div>
              <Label>Voice Note (Optional)</Label>
              <div className="mt-2">
                <Button
                  type="button"
                  variant={isRecording ? "destructive" : "outline"}
                  className="w-full"
                  onClick={handleVoiceRecording}
                >
                  <Mic className="mr-2 h-4 w-4" />
                  {isRecording ? "Stop Recording" : "Record Voice Note"}
                </Button>
              </div>

              {voiceNote && (
                <div className="mt-3 flex items-center justify-between rounded-lg bg-muted p-3">
                  <div className="text-sm">
                    <p className="font-medium">Voice Recording</p>
                    <p className="text-xs text-muted-foreground">{voiceNote.duration} seconds</p>
                  </div>
                  <Button type="button" variant="ghost" size="sm" onClick={removeVoiceNote}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </div>
          </div>

          <div className="flex gap-4">
            <Button type="button" variant="outline" className="flex-1 bg-transparent" onClick={() => router.back()}>
              Cancel
            </Button>
            <Button type="submit" className="flex-1" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Submitting...
                </>
              ) : (
                "Submit Grievance"
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
