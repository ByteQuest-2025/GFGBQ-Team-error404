"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Search, FileText, Clock, CheckCircle2, XCircle, Eye, AlertCircle, MapPin, Calendar } from "lucide-react"
import { getGrievanceById } from "@/lib/grievance-storage"
import type { Grievance } from "@/lib/types"
import { formatDistanceToNow, format } from "date-fns"
import Link from "next/link"
import { StatusProgress } from "@/components/status-progress"

export default function TrackComplaintPage() {
  const [trackingId, setTrackingId] = useState("")
  const [grievance, setGrievance] = useState<Grievance | null>(null)
  const [error, setError] = useState("")

  const handleSearch = () => {
    setError("")
    setGrievance(null)

    if (!trackingId.trim()) {
      setError("Please enter a tracking ID")
      return
    }

    const found = getGrievanceById(trackingId)
    if (found) {
      setGrievance(found)
    } else {
      setError("No complaint found with this tracking ID")
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-amber-500"
      case "in-review":
        return "bg-blue-500"
      case "in-progress":
        return "bg-purple-500"
      case "resolved":
        return "bg-green-500"
      case "rejected":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="h-5 w-5" />
      case "in-review":
        return <Eye className="h-5 w-5" />
      case "in-progress":
        return <AlertCircle className="h-5 w-5" />
      case "resolved":
        return <CheckCircle2 className="h-5 w-5" />
      case "rejected":
        return <XCircle className="h-5 w-5" />
      default:
        return <FileText className="h-5 w-5" />
    }
  }

  const getTimeline = (grievance: Grievance) => {
    const timeline = [
      {
        status: "pending",
        label: "Complaint Submitted",
        date: grievance.createdAt,
        completed: true,
      },
      {
        status: "in-review",
        label: "Under Review",
        date:
          grievance.status === "in-review" || grievance.status === "in-progress" || grievance.status === "resolved"
            ? grievance.updatedAt
            : null,
        completed:
          grievance.status === "in-review" || grievance.status === "in-progress" || grievance.status === "resolved",
      },
      {
        status: "in-progress",
        label: "In Progress",
        date: grievance.status === "in-progress" || grievance.status === "resolved" ? grievance.updatedAt : null,
        completed: grievance.status === "in-progress" || grievance.status === "resolved",
      },
      {
        status: "resolved",
        label: "Resolved",
        date: grievance.status === "resolved" ? grievance.resolvedAt : null,
        completed: grievance.status === "resolved",
      },
    ]

    if (grievance.status === "rejected") {
      return [
        timeline[0],
        {
          status: "rejected",
          label: "Rejected",
          date: grievance.updatedAt,
          completed: true,
        },
      ]
    }

    return timeline
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="h-10 w-10 rounded-lg bg-primary flex items-center justify-center">
              <FileText className="h-6 w-6 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold">GrievAi</span>
          </Link>
          <div className="flex gap-2">
            <Button variant="ghost" asChild>
              <Link href="/login">Login</Link>
            </Button>
            <Button asChild>
              <Link href="/register">Register</Link>
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12 max-w-4xl">
        {/* Search Section */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-2xl">Track Your Complaint</CardTitle>
            <CardDescription>Enter your tracking ID to view the status of your grievance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-3">
              <div className="flex-1">
                <Label htmlFor="tracking-id" className="sr-only">
                  Tracking ID
                </Label>
                <Input
                  id="tracking-id"
                  placeholder="Enter tracking ID (e.g., GRV-1234567890)"
                  value={trackingId}
                  onChange={(e) => setTrackingId(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                  className="h-12"
                />
              </div>
              <Button onClick={handleSearch} size="lg" className="px-8">
                <Search className="mr-2 h-4 w-4" />
                Track
              </Button>
            </div>
            {error && <p className="text-sm text-destructive mt-2">{error}</p>}
          </CardContent>
        </Card>

        {/* Results Section */}
        {grievance && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Live Status</CardTitle>
                <CardDescription>Real-time progress of your complaint</CardDescription>
              </CardHeader>
              <CardContent>
                <StatusProgress currentStatus={grievance.status} size="lg" />
              </CardContent>
            </Card>

            {/* Complaint Overview */}
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-xl mb-2">{grievance.title}</CardTitle>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="outline" className={getStatusColor(grievance.status) + " text-white border-0"}>
                        {grievance.status.replace(/-/g, " ").toUpperCase()}
                      </Badge>
                      {grievance.priority && (
                        <Badge variant="secondary" className="capitalize">
                          {grievance.priority} Priority
                        </Badge>
                      )}
                      {grievance.category && (
                        <Badge variant="outline" className="capitalize">
                          {grievance.category.replace(/-/g, " ")}
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">Description</h4>
                  <p className="text-muted-foreground">{grievance.description}</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t">
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span className="text-muted-foreground">Submitted:</span>
                    <span className="font-medium">{format(new Date(grievance.createdAt), "PPP")}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-muted-foreground">Last Updated:</span>
                    <span className="font-medium">
                      {formatDistanceToNow(new Date(grievance.updatedAt), { addSuffix: true })}
                    </span>
                  </div>
                  {grievance.location && (
                    <div className="flex items-center gap-2 text-sm md:col-span-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span className="text-muted-foreground">Location:</span>
                      <span className="font-medium">{grievance.location}</span>
                    </div>
                  )}
                </div>

                {grievance.aiAnalysis && (
                  <div className="pt-4 border-t">
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <AlertCircle className="h-4 w-4" />
                      AI Analysis
                    </h4>
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <span className="text-muted-foreground">Department:</span>
                        <p className="font-medium">{grievance.aiAnalysis.suggestedDepartment}</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Est. Resolution:</span>
                        <p className="font-medium">{grievance.aiAnalysis.estimatedResolutionDays} days</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Sentiment:</span>
                        <p className="font-medium capitalize">{grievance.aiAnalysis.sentiment.replace(/-/g, " ")}</p>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Confidence:</span>
                        <p className="font-medium">{Math.round(grievance.aiAnalysis.confidence * 100)}%</p>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Status Timeline */}
            <Card>
              <CardHeader>
                <CardTitle>Status Timeline</CardTitle>
                <CardDescription>Track the progress of your complaint</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {getTimeline(grievance).map((step, index) => (
                    <div key={step.status} className="flex gap-4">
                      <div className="flex flex-col items-center">
                        <div
                          className={`h-10 w-10 rounded-full flex items-center justify-center ${
                            step.completed
                              ? getStatusColor(step.status) + " text-white"
                              : "bg-muted text-muted-foreground"
                          }`}
                        >
                          {getStatusIcon(step.status)}
                        </div>
                        {index < getTimeline(grievance).length - 1 && (
                          <div className={`w-0.5 h-12 ${step.completed ? "bg-primary" : "bg-muted"}`} />
                        )}
                      </div>
                      <div className="flex-1 pb-8">
                        <h4 className={`font-semibold ${step.completed ? "text-foreground" : "text-muted-foreground"}`}>
                          {step.label}
                        </h4>
                        {step.date && (
                          <p className="text-sm text-muted-foreground mt-1">
                            {format(new Date(step.date), "PPP 'at' p")}
                          </p>
                        )}
                        {!step.date && !step.completed && <p className="text-sm text-muted-foreground mt-1">Pending</p>}
                      </div>
                    </div>
                  ))}
                </div>

                {grievance.resolutionNotes && (
                  <div className="mt-6 pt-6 border-t">
                    <h4 className="font-semibold mb-2">Resolution Notes</h4>
                    <p className="text-sm text-muted-foreground">{grievance.resolutionNotes}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Help Section */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertCircle className="h-5 w-5 text-muted-foreground mt-0.5" />
                  <div>
                    <h4 className="font-semibold mb-1">Need Help?</h4>
                    <p className="text-sm text-muted-foreground">
                      If you have questions about your complaint or need to provide additional information, please{" "}
                      <Link href="/login" className="text-primary hover:underline">
                        log in to your account
                      </Link>{" "}
                      or contact support.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
