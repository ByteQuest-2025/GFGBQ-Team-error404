"use client"

import { AuthGuard } from "@/components/auth-guard"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ComplaintMap } from "@/components/complaint-map"
import { calculateDashboardStats } from "@/lib/analytics"
import { getCurrentUser } from "@/lib/auth"
import { getAllGrievances } from "@/lib/grievance-storage"
import { useEffect, useState } from "react"
import type { DashboardStats, Grievance } from "@/lib/types"
import { FileText, Clock, CheckCircle2, AlertTriangle, TrendingUp, BarChart3 } from "lucide-react"
import { useRouter } from "next/navigation"

export default function AdminDashboard() {
  return (
    <AuthGuard requiredRole="admin">
      <AdminDashboardContent />
    </AuthGuard>
  )
}

function AdminDashboardContent() {
  const router = useRouter()
  const [stats, setStats] = useState<DashboardStats | null>(null)
  const [user, setUser] = useState<ReturnType<typeof getCurrentUser>>(null)
  const [grievances, setGrievances] = useState<Grievance[]>([])

  useEffect(() => {
    setUser(getCurrentUser())
    setStats(calculateDashboardStats())
    setGrievances(getAllGrievances())
  }, [])

  if (!stats) {
    return <div>Loading...</div>
  }

  return (
    <DashboardLayout title="Admin Dashboard" userName={user?.name || ""} userRole="admin">
      <div className="space-y-6">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card
            className="cursor-pointer hover:shadow-md transition-shadow"
            onClick={() => router.push("/admin/grievances")}
          >
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Grievances</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalGrievances}</div>
              <p className="text-xs text-muted-foreground mt-1">All time submissions</p>
            </CardContent>
          </Card>

          <Card
            className="cursor-pointer hover:shadow-md transition-shadow"
            onClick={() => router.push("/admin/grievances?status=pending")}
          >
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Review</CardTitle>
              <Clock className="h-4 w-4 text-amber-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.pendingGrievances}</div>
              <p className="text-xs text-muted-foreground mt-1">Awaiting action</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Critical Issues</CardTitle>
              <AlertTriangle className="h-4 w-4 text-red-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.criticalGrievances}</div>
              <p className="text-xs text-muted-foreground mt-1">Requires immediate attention</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Resolution Rate</CardTitle>
              <CheckCircle2 className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.resolutionRate}%</div>
              <p className="text-xs text-muted-foreground mt-1">Avg: {stats.avgResolutionTime} days</p>
            </CardContent>
          </Card>
        </div>

        <ComplaintMap grievances={grievances} showTitle={true} />

        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Category Distribution
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {Object.entries(stats.categoryDistribution).map(([category, count]) => (
                  <div key={category}>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="capitalize">{category.replace(/-/g, " ")}</span>
                      <span className="font-medium">{count}</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary"
                        style={{
                          width: `${stats.totalGrievances > 0 ? (count / stats.totalGrievances) * 100 : 0}%`,
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Priority Breakdown
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {Object.entries(stats.priorityDistribution).map(([priority, count]) => {
                  const colors: Record<string, string> = {
                    critical: "bg-red-500",
                    high: "bg-orange-500",
                    medium: "bg-yellow-500",
                    low: "bg-green-500",
                  }

                  return (
                    <div key={priority}>
                      <div className="flex items-center justify-between text-sm mb-1">
                        <span className="capitalize">{priority}</span>
                        <span className="font-medium">{count}</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div
                          className={`h-full ${colors[priority] || "bg-gray-500"}`}
                          style={{
                            width: `${stats.totalGrievances > 0 ? (count / stats.totalGrievances) * 100 : 0}%`,
                          }}
                        />
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Sentiment Analysis</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-5 gap-4">
              {Object.entries(stats.sentimentDistribution).map(([sentiment, count]) => {
                const sentimentColors: Record<string, string> = {
                  "very-negative": "text-red-600",
                  negative: "text-orange-600",
                  neutral: "text-gray-600",
                  positive: "text-blue-600",
                  "very-positive": "text-green-600",
                }

                return (
                  <div key={sentiment} className="text-center">
                    <div className={`text-3xl font-bold ${sentimentColors[sentiment]}`}>{count}</div>
                    <p className="text-xs text-muted-foreground mt-1 capitalize">{sentiment.replace(/-/g, " ")}</p>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
