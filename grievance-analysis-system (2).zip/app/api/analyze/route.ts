import { analyzeGrievance } from "@/lib/ai-analysis"

export async function POST(req: Request) {
  try {
    const { title, description, voiceTranscription } = await req.json()

    if (!title || !description) {
      return Response.json({ error: "Title and description are required" }, { status: 400 })
    }

    const analysis = await analyzeGrievance(title, description, voiceTranscription)

    return Response.json({ analysis })
  } catch (error) {
    console.error("Analysis error:", error)
    return Response.json({ error: "Failed to analyze grievance" }, { status: 500 })
  }
}
