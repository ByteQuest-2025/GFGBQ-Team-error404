import type { DashboardStats, GrievanceCategory, PriorityLevel, SentimentType } from "./types"
import { getGrievances } from "./grievance-storage"

export function calculateDashboardStats(): DashboardStats {
  const grievances = getGrievances()

  const totalGrievances = grievances.length
  const pendingGrievances = grievances.filter((g) => g.status === "pending").length
  const inProgressGrievances = grievances.filter((g) => g.status === "in-progress" || g.status === "in-review").length
  const resolvedGrievances = grievances.filter((g) => g.status === "resolved").length
  const criticalGrievances = grievances.filter((g) => g.priority === "critical").length

  // Calculate average resolution time
  const resolved = grievances.filter((g) => g.status === "resolved" && g.resolvedAt)
  const avgResolutionTime =
    resolved.length > 0
      ? resolved.reduce((sum, g) => {
          const created = new Date(g.createdAt).getTime()
          const resolvedTime = new Date(g.resolvedAt!).getTime()
          return sum + (resolvedTime - created) / (1000 * 60 * 60 * 24) // days
        }, 0) / resolved.length
      : 0

  // Category distribution
  const categoryDistribution: Record<GrievanceCategory, number> = {
    "civic-infrastructure": 0,
    sanitation: 0,
    "public-safety": 0,
    utilities: 0,
    healthcare: 0,
    education: 0,
    administrative: 0,
  }

  grievances.forEach((g) => {
    if (g.category) {
      categoryDistribution[g.category]++
    }
  })

  // Priority distribution
  const priorityDistribution: Record<PriorityLevel, number> = {
    critical: 0,
    high: 0,
    medium: 0,
    low: 0,
  }

  grievances.forEach((g) => {
    if (g.priority) {
      priorityDistribution[g.priority]++
    }
  })

  // Sentiment distribution
  const sentimentDistribution: Record<SentimentType, number> = {
    "very-negative": 0,
    negative: 0,
    neutral: 0,
    positive: 0,
    "very-positive": 0,
  }

  grievances.forEach((g) => {
    if (g.aiAnalysis?.sentiment) {
      sentimentDistribution[g.aiAnalysis.sentiment]++
    }
  })

  // Daily submissions (last 30 days)
  const dailySubmissions: Array<{ date: string; count: number }> = []
  const today = new Date()

  for (let i = 29; i >= 0; i--) {
    const date = new Date(today)
    date.setDate(date.getDate() - i)
    const dateStr = date.toISOString().split("T")[0]

    const count = grievances.filter((g) => {
      const gDate = new Date(g.createdAt).toISOString().split("T")[0]
      return gDate === dateStr
    }).length

    dailySubmissions.push({ date: dateStr, count })
  }

  // Resolution rate
  const resolutionRate = totalGrievances > 0 ? (resolvedGrievances / totalGrievances) * 100 : 0

  return {
    totalGrievances,
    pendingGrievances,
    inProgressGrievances,
    resolvedGrievances,
    criticalGrievances,
    avgResolutionTime: Math.round(avgResolutionTime * 10) / 10,
    categoryDistribution,
    priorityDistribution,
    sentimentDistribution,
    dailySubmissions,
    resolutionRate: Math.round(resolutionRate * 10) / 10,
  }
}
