export type UserRole = "citizen" | "admin"

export interface User {
  id: string
  email: string
  name: string
  role: UserRole
  createdAt: string
}

export type GrievanceCategory =
  | "civic-infrastructure"
  | "sanitation"
  | "public-safety"
  | "utilities"
  | "healthcare"
  | "education"
  | "administrative"

export type GrievanceStatus = "pending" | "in-review" | "in-progress" | "resolved" | "rejected"

export type PriorityLevel = "critical" | "high" | "medium" | "low"

export type SentimentType = "very-negative" | "negative" | "neutral" | "positive" | "very-positive"

export interface AIAnalysis {
  category: GrievanceCategory
  priority: PriorityLevel
  sentiment: SentimentType
  keywords: string[]
  suggestedDepartment: string
  estimatedResolutionDays: number
  confidence: number
}

export interface Grievance {
  id: string
  citizenId: string
  citizenName: string
  citizenEmail: string
  title: string
  description: string
  category?: GrievanceCategory
  status: GrievanceStatus
  priority?: PriorityLevel
  aiAnalysis?: AIAnalysis
  attachments?: FileAttachment[]
  voiceNote?: VoiceNote
  location?: string
  createdAt: string
  updatedAt: string
  assignedTo?: string
  resolutionNotes?: string
  resolvedAt?: string
}

export interface FileAttachment {
  id: string
  name: string
  type: string
  size: number
  url: string
}

export interface VoiceNote {
  id: string
  duration: number
  url: string
  transcription?: string
}

export interface DashboardStats {
  totalGrievances: number
  pendingGrievances: number
  inProgressGrievances: number
  resolvedGrievances: number
  criticalGrievances: number
  avgResolutionTime: number
  categoryDistribution: Record<GrievanceCategory, number>
  priorityDistribution: Record<PriorityLevel, number>
  sentimentDistribution: Record<SentimentType, number>
  dailySubmissions: Array<{ date: string; count: number }>
  resolutionRate: number
}
