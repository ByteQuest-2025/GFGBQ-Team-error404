import { generateObject } from "ai"
import { z } from "zod"
import type { AIAnalysis, GrievanceCategory, PriorityLevel, SentimentType } from "./types"

const aiAnalysisSchema = z.object({
  category: z.enum([
    "civic-infrastructure",
    "sanitation",
    "public-safety",
    "utilities",
    "healthcare",
    "education",
    "administrative",
  ]),
  priority: z.enum(["critical", "high", "medium", "low"]),
  sentiment: z.enum(["very-negative", "negative", "neutral", "positive", "very-positive"]),
  keywords: z.array(z.string()),
  suggestedDepartment: z.string(),
  estimatedResolutionDays: z.number(),
  confidence: z.number().min(0).max(1),
})

export async function analyzeGrievance(
  title: string,
  description: string,
  voiceTranscription?: string,
): Promise<AIAnalysis> {
  const fullText = [
    `Title: ${title}`,
    `Description: ${description}`,
    voiceTranscription ? `Voice Note: ${voiceTranscription}` : "",
  ]
    .filter(Boolean)
    .join("\n")

  try {
    const { object } = await generateObject({
      model: "openai/gpt-5",
      schema: aiAnalysisSchema,
      prompt: `You are an AI system analyzing citizen grievances for a public governance platform. 
      
Analyze the following grievance and provide:
1. Category: What type of issue is this? (civic-infrastructure, sanitation, public-safety, utilities, healthcare, education, administrative)
2. Priority: How urgent is this? (critical, high, medium, low)
   - critical: immediate danger, safety issues, major service outages
   - high: significant impact on quality of life, widespread issues
   - medium: moderate inconvenience, localized problems
   - low: minor issues, suggestions
3. Sentiment: What's the emotional tone? (very-negative, negative, neutral, positive, very-positive)
4. Keywords: Extract 3-5 key terms
5. Suggested Department: Which department should handle this?
6. Estimated Resolution Days: Based on issue complexity (1-90 days)
7. Confidence: Your confidence in this analysis (0.0 to 1.0)

Grievance:
${fullText}`,
    })

    return object as AIAnalysis
  } catch (error) {
    console.error("AI analysis failed:", error)
    // Fallback to basic analysis
    return mockAnalysis(title, description)
  }
}

// Fallback mock analysis if AI fails
function mockAnalysis(title: string, description: string): AIAnalysis {
  const text = `${title} ${description}`.toLowerCase()

  let category: GrievanceCategory = "administrative"
  if (text.includes("road") || text.includes("bridge") || text.includes("infrastructure")) {
    category = "civic-infrastructure"
  } else if (text.includes("garbage") || text.includes("waste") || text.includes("clean")) {
    category = "sanitation"
  } else if (text.includes("safety") || text.includes("crime") || text.includes("police")) {
    category = "public-safety"
  } else if (text.includes("water") || text.includes("electricity") || text.includes("power")) {
    category = "utilities"
  } else if (text.includes("health") || text.includes("hospital") || text.includes("doctor")) {
    category = "healthcare"
  } else if (text.includes("school") || text.includes("education") || text.includes("teacher")) {
    category = "education"
  }

  let priority: PriorityLevel = "medium"
  if (text.includes("urgent") || text.includes("emergency") || text.includes("critical")) {
    priority = "critical"
  } else if (text.includes("important") || text.includes("serious")) {
    priority = "high"
  } else if (text.includes("minor") || text.includes("small")) {
    priority = "low"
  }

  let sentiment: SentimentType = "neutral"
  if (text.includes("terrible") || text.includes("worst") || text.includes("horrible")) {
    sentiment = "very-negative"
  } else if (text.includes("bad") || text.includes("poor") || text.includes("disappointed")) {
    sentiment = "negative"
  } else if (text.includes("good") || text.includes("thank")) {
    sentiment = "positive"
  }

  return {
    category,
    priority,
    sentiment,
    keywords: text.split(" ").slice(0, 5),
    suggestedDepartment:
      category
        .split("-")
        .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
        .join(" ") + " Department",
    estimatedResolutionDays: priority === "critical" ? 2 : priority === "high" ? 7 : priority === "medium" ? 14 : 30,
    confidence: 0.75,
  }
}
